import uuid
import docker
import tempfile
import os
import shutil
import time
from typing import Dict, Any

DOCKER_CLIENT = docker.from_env(timeout=10)
IMAGE_MAP = {
    "python:3.11-slim": {
        "name": "python:3.11-slim",
        "cmd": ["python", "/workspace/snippet.py"]
    },
    # Extend with other languages as needed
}

DEFAULT_TIMEOUT = 6  # seconds
DEFAULT_CPU_PERIOD = 100000
DEFAULT_CPU_QUOTA = 50000  # ~50% of one CPU
DEFAULT_MEMORY = "200m"  # 200MB

def run_snippet_docker(image_key: str, code: str, timeout: int = DEFAULT_TIMEOUT) -> Dict[str, Any]:
    if image_key not in IMAGE_MAP:
        raise ValueError("Unsupported image")

    rid = str(uuid.uuid4())[:8]
    workdir = tempfile.mkdtemp(prefix=f"run-{rid}-")
    try:
        snippet_path = os.path.join(workdir, "snippet.py")
        with open(snippet_path, "w") as f:
            f.write(code)

        volumes = {
            workdir: {"bind": "/workspace", "mode": "ro"}
        }

        container = DOCKER_CLIENT.containers.run(
            IMAGE_MAP[image_key]["name"],
            IMAGE_MAP[image_key]["cmd"],
            detach=True,
            volumes=volumes,
            network_disabled=True,
            working_dir="/workspace",
            user="nobody",
            cpu_period=DEFAULT_CPU_PERIOD,
            cpu_quota=DEFAULT_CPU_QUOTA,
            mem_limit=DEFAULT_MEMORY,
            pids_limit=64,
            security_opt=[
                "no-new-privileges",
                "seccomp=unconfined"
            ],
        )

        start = time.time()
        try:
            exit_status = container.wait(timeout=timeout)
            runtime = time.time() - start
            logs = container.logs(stdout=True, stderr=True)
            stdout = logs.decode(errors="replace")
            return {
                "stdout": stdout,
                "stderr": None,
                "exit_code": exit_status.get("StatusCode", 0),
                "runtime_seconds": runtime,
                "container_id": container.id
            }
        except Exception as e:
            try:
                container.kill()
            except Exception:
                pass
            return {"stdout": "", "stderr": f"Execution timeout or error: {str(e)}", "exit_code": -1, "container_id": container.id}
        finally:
            try:
                container.remove(force=True)
            except Exception:
                pass
    finally:
        try:
            shutil.rmtree(workdir)
        except Exception:
            pass