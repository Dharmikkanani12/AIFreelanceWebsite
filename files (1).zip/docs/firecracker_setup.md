# Firecracker MicroVM Setup Guide

## Overview
Firecracker is a virtualization solution for running secure, lightweight microVMs—ideal for executing untrusted code with strong isolation.

## Steps

1. **Install Firecracker**
   - Download binaries: https://github.com/firecracker-microvm/firecracker
   - Ensure your host supports KVM and virtualization.

2. **Create a Minimal RootFS**
   - Use `buildroot` or a tiny Linux image.
   - Instructions: https://github.com/firecracker-microvm/firecracker/blob/main/docs/rootfs-and-kernel.md

3. **Launch a MicroVM**
   - Provide kernel and rootfs via Firecracker API.
   - Example:
     ```
     firecracker --api-sock /tmp/firecracker.sock
     curl -X PUT --unix-socket /tmp/firecracker.sock -H 'Content-Type: application/json' \
         -d '{"kernel_image_path":"/path/to/vmlinux"}' http://localhost/boot-source
     curl -X PUT --unix-socket /tmp/firecracker.sock -H 'Content-Type: application/json' \
         -d '{"drive_id":"rootfs","path_on_host":"/path/to/rootfs"}' http://localhost/drives/rootfs
     curl -X PUT --unix-socket /tmp/firecracker.sock -H 'Content-Type: application/json' \
         -d '{"vcpu_count":1, "mem_size_mib":128}' http://localhost/machine-config
     curl -X PUT --unix-socket /tmp/firecracker.sock -H 'Content-Type: application/json' \
         -d '{"args":["python3", "/workspace/snippet.py"]}' http://localhost/actions
     ```

4. **Automate with Python**
   - Use [firecracker-python-sdk](https://github.com/firecracker-microvm/firecracker-sdk-python) for programmatic control.

5. **Security**
   - Always limit resources and verify rootFS is unprivileged.
   - Log all runs.

## For full orchestration, see the Firecracker docs and consider using a runner pool or queue (with Redis/RabbitMQ, etc).